/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sueldos;

/**
 *
 * @author ander
 */
public class Empleado {
    private String nombre;
    private double salarioBase;
    private int horasTrabajadas;
    private double descuento;

    public Empleado(String nombre, double salarioBase, int horasTrabajadas, double descuento) {
        this.nombre = nombre;
        this.salarioBase = salarioBase;
        this.horasTrabajadas = horasTrabajadas;
        this.descuento = descuento;
    }

    public double calcularSueldoBruto() {
        return salarioBase * horasTrabajadas;
    }

    public double calcularSueldoNeto() {
        return calcularSueldoBruto() - descuento;
    }
}
